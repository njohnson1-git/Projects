`timescale 1ns / 1ps

// video_subsystem.v
// Contains VGA timing for 640x480@60Hz and a simple test pattern renderer.

//////////////////////////////////////////////////////////////
// VGA timing generator for 640x480 @ 60 Hz, 25 MHz pixel clk
//////////////////////////////////////////////////////////////
module vga (
    input  wire        clk_pix,
    input  wire        reset,
    output reg  [9:0]  hcount,       // 0..799
    output reg  [9:0]  vcount,       // 0..524
    output reg         hsync,
    output reg         vsync,
    output wire        video_active
);
    // Horizontal timing (in pixels)
    localparam H_VISIBLE   = 640;
    localparam H_FRONT_PORCH = 16;
    localparam H_SYNC      = 96;
    localparam H_BACK_PORCH = 48;
    localparam H_TOTAL     = H_VISIBLE + H_FRONT_PORCH + H_SYNC + H_BACK_PORCH; // 800

    // Vertical timing (in lines)
    localparam V_VISIBLE   = 480;
    localparam V_FRONT_PORCH = 10;
    localparam V_SYNC      = 2;
    localparam V_BACK_PORCH = 33;
    localparam V_TOTAL     = V_VISIBLE + V_FRONT_PORCH + V_SYNC + V_BACK_PORCH; // 525

    // Horizontal & vertical counters
    always @(posedge clk_pix or posedge reset) begin
        if (reset) begin
            hcount <= 10'd0;
            vcount <= 10'd0;
        end else begin
            if (hcount == H_TOTAL - 1) begin
                hcount <= 10'd0;
                if (vcount == V_TOTAL - 1)
                    vcount <= 10'd0;
                else
                    vcount <= vcount + 10'd1;
            end else begin
                hcount <= hcount + 10'd1;
            end
        end
    end

    // Generate sync pulses (active low)
    always @(posedge clk_pix or posedge reset) begin
        if (reset) begin
            hsync <= 1'b1;
            vsync <= 1'b1;
        end else begin
            // HSYNC low during sync period
            hsync <= ~((hcount >= (H_VISIBLE + H_FRONT_PORCH)) &&
                       (hcount <  (H_VISIBLE + H_FRONT_PORCH + H_SYNC)));

            // VSYNC low during sync period
            vsync <= ~((vcount >= (V_VISIBLE + V_FRONT_PORCH)) &&
                       (vcount <  (V_VISIBLE + V_FRONT_PORCH + V_SYNC)));
        end
    end

    // "Active" video region (where pixels are actually visible)
    assign video_active = (hcount < H_VISIBLE) && (vcount < V_VISIBLE);

endmodule


//////////////////////////////////////////////////////////////
// Simple test pattern: color bars + checkerboard
//////////////////////////////////////////////////////////////
module test_pattern_renderer (
    input  wire [9:0] hcount,
    input  wire [9:0] vcount,
    input  wire       video_active,
    output reg  [3:0] vga_r,
    output reg  [3:0] vga_g,
    output reg  [3:0] vga_b
);
    always @* begin
        if (!video_active) begin
            // Outside visible area: black
            vga_r = 4'h0;
            vga_g = 4'h0;
            vga_b = 4'h0;
        end else begin
            // Simple color bars based on horizontal position
            // 640 pixels wide -> let's split into 4 regions of 160 each
            if (hcount < 160) begin
                // Red
                vga_r = 4'hF;
                vga_g = 4'h0;
                vga_b = 4'h0;
            end else if (hcount < 320) begin
                // Green
                vga_r = 4'h0;
                vga_g = 4'hF;
                vga_b = 4'h0;
            end else if (hcount < 480) begin
                // Blue
                vga_r = 4'h0;
                vga_g = 4'h0;
                vga_b = 4'hF;
            end else begin
                // White with a checker pattern using hcount/vcount bits
                if (hcount[4] ^ vcount[4]) begin
                    vga_r = 4'hF;
                    vga_g = 4'hF;
                    vga_b = 4'hF;
                end else begin
                    vga_r = 4'h8;
                    vga_g = 4'h8;
                    vga_b = 4'h8;
                end
            end
        end
    end
endmodule


//////////////////////////////////////////////////////////////
// game_renderer: background + ship (with triangle nose) +
//                player bullet + enemy formation +
//                one enemy bullet + WIN/LOSE text overlay.
//////////////////////////////////////////////////////////////
module game_renderer (
    input  wire [9:0] hcount,
    input  wire [9:0] vcount,
    input  wire       video_active,
    input  wire [9:0] ship_x,
    input  wire [9:0] ship_y,
    input  wire       bullet_active,
    input  wire [9:0] bullet_x,
    input  wire [9:0] bullet_y,
    input  wire [9:0] enemy_group_x,
    input  wire [9:0] enemy_group_y,
    input  wire [23:0] enemy_alive,     // 3x8 formation
    input  wire       ebullet_active,
    input  wire [9:0] ebullet_x,
    input  wire [9:0] ebullet_y,
    input  wire       game_over,
    input  wire       you_win,
    input  wire       you_lose,

    output reg  [3:0] vga_r,
    output reg  [3:0] vga_g,
    output reg  [3:0] vga_b
);
    // Ship & bullets
    localparam integer SHIP_W    = 32;
    localparam integer SHIP_H    = 16;
    localparam integer NOSE_H    = 8;   // height of triangle nose
    localparam integer BULLET_W  = 4;
    localparam integer BULLET_H  = 8;

    // Enemies
    localparam integer ENEMY_W   = 24;
    localparam integer ENEMY_H   = 16;
    localparam integer H_SPACING = 16;
    localparam integer V_SPACING = 12;
    localparam integer N_ROWS    = 3;
    localparam integer N_COLS    = 8;

    // Text layout (WIN / LOSE)
    localparam integer LETTER_W      = 18;
    localparam integer LETTER_H      = 24;
    localparam integer LETTER_SP     = 6;

    localparam integer WIN_TEXT_X    = 160;
    localparam integer WIN_TEXT_Y    = 120;

    localparam integer LOSE_TEXT_X   = 140;
    localparam integer LOSE_TEXT_Y   = 120;

    // ----------------------------------------------------------------
    // Ship shape: rectangle + triangle nose
    // ----------------------------------------------------------------
    // Ship rectangle
    wire in_ship_rect = (hcount >= ship_x) &&
                        (hcount <  ship_x + SHIP_W) &&
                        (vcount >= ship_y) &&
                        (vcount <  ship_y + SHIP_H);

    // Triangle nose ABOVE the ship
    wire [9:0] ship_center_x = ship_x + (SHIP_W >> 1);
    
    // vertical distance from top of nose region
    wire [9:0] dy_nose = (ship_y - vcount);   // 0 at ship, NOSE_H at top

    wire in_ship_nose =
        (vcount >= ship_y - NOSE_H) &&        // only above ship
        (vcount <  ship_y) &&
        (hcount >= ship_center_x - (dy_nose >> 1)) &&
        (hcount <  ship_center_x + (dy_nose >> 1));

    wire in_ship = in_ship_rect | in_ship_nose;


    // ----------------------------------------------------------------
    // Bullets
    // ----------------------------------------------------------------
    wire in_player_bullet = bullet_active &&
                            (hcount >= bullet_x) &&
                            (hcount <  bullet_x + BULLET_W) &&
                            (vcount >= bullet_y) &&
                            (vcount <  bullet_y + BULLET_H);

    wire in_enemy_bullet = ebullet_active &&
                           (hcount >= ebullet_x) &&
                           (hcount <  ebullet_x + BULLET_W) &&
                           (vcount >= ebullet_y) &&
                           (vcount <  ebullet_y + BULLET_H);

    // ----------------------------------------------------------------
    // Enemies (3x8 formation)
    // ----------------------------------------------------------------
    reg in_enemy;
    integer r, c, idx;
    integer ex0, ex1, ey0, ey1;

    always @* begin
        in_enemy = 1'b0;

        for (r = 0; r < N_ROWS; r = r+1) begin
            for (c = 0; c < N_COLS; c = c+1) begin
                idx = r*N_COLS + c;
                if (enemy_alive[idx]) begin
                    ex0 = enemy_group_x + c * (ENEMY_W + H_SPACING);
                    ex1 = ex0 + ENEMY_W;
                    ey0 = enemy_group_y + r * (ENEMY_H + V_SPACING);
                    ey1 = ey0 + ENEMY_H;

                    if ((hcount >= ex0[9:0]) &&
                        (hcount <  ex1[9:0]) &&
                        (vcount >= ey0[9:0]) &&
                        (vcount <  ey1[9:0])) begin
                        in_enemy = 1'b1;
                    end
                end
            end
        end
    end

    // ----------------------------------------------------------------
    // WIN text ("WIN") and LOSE text ("LOSE") overlay
    // Each letter = simple blocks of vertical/horizontal bars.
    // ----------------------------------------------------------------

    // WIN word positions
    wire in_W_region = (hcount >= WIN_TEXT_X) &&
                       (hcount <  WIN_TEXT_X + LETTER_W) &&
                       (vcount >= WIN_TEXT_Y) &&
                       (vcount <  WIN_TEXT_Y + LETTER_H);

    wire in_I_region = (hcount >= WIN_TEXT_X + LETTER_W + LETTER_SP) &&
                       (hcount <  WIN_TEXT_X + (LETTER_W + LETTER_SP)*2) &&
                       (vcount >= WIN_TEXT_Y) &&
                       (vcount <  WIN_TEXT_Y + LETTER_H);

    wire in_N_region = (hcount >= WIN_TEXT_X + (LETTER_W + LETTER_SP)*2) &&
                       (hcount <  WIN_TEXT_X + (LETTER_W + LETTER_SP)*3) &&
                       (vcount >= WIN_TEXT_Y) &&
                       (vcount <  WIN_TEXT_Y + LETTER_H);

    // relative coords inside each WIN letter
    wire [9:0] x_W = hcount - WIN_TEXT_X;
    wire [9:0] y_W = vcount - WIN_TEXT_Y;

    wire [9:0] x_I = hcount - (WIN_TEXT_X + LETTER_W + LETTER_SP);
    wire [9:0] y_I = vcount - WIN_TEXT_Y;

    wire [9:0] x_N = hcount - (WIN_TEXT_X + (LETTER_W + LETTER_SP)*2);
    wire [9:0] y_N = vcount - WIN_TEXT_Y;

    // Very simple blocky "W"
    wire pixel_W =
        (x_W < 3 && y_W < LETTER_H) ||                                    // left bar
        (x_W >= LETTER_W-3 && x_W < LETTER_W && y_W < LETTER_H) ||        // right bar
        (y_W >= LETTER_H-5 && y_W < LETTER_H &&                           // bottom "V"
         x_W >= (LETTER_W/3) && x_W < (LETTER_W - LETTER_W/3));

    // "I": center bar + top & bottom bars
    wire pixel_I =
        (y_I < 3 && x_I < LETTER_W) ||                                    // top bar
        (y_I >= LETTER_H-3 && y_I < LETTER_H && x_I < LETTER_W) ||        // bottom bar
        (x_I >= (LETTER_W/2 - 1) && x_I <= (LETTER_W/2 + 1) &&            // center stem
         y_I < LETTER_H);

    // "N": two side bars + approximate diagonal center stroke

    // crude diagonal: x ≈ (y * LETTER_W / LETTER_H)
    wire [9:0] diag_x_N = (y_N * LETTER_W) / LETTER_H;

    wire pixel_N =
        // left vertical bar
        (x_N < 3 && y_N < LETTER_H) ||

        // right vertical bar
        (x_N >= LETTER_W-3 && x_N < LETTER_W && y_N < LETTER_H) ||

        // diagonal-ish center: a 3-pixel-wide band around diag_x_N
        ((x_N >= diag_x_N && x_N < diag_x_N + 3) && y_N < LETTER_H);


    wire win_text_pixel = (in_W_region && pixel_W) ||
                          (in_I_region && pixel_I) ||
                          (in_N_region && pixel_N);

    // LOSE word positions
    wire in_L_region = (hcount >= LOSE_TEXT_X) &&
                       (hcount <  LOSE_TEXT_X + LETTER_W) &&
                       (vcount >= LOSE_TEXT_Y) &&
                       (vcount <  LOSE_TEXT_Y + LETTER_H);

    wire in_O_region = (hcount >= LOSE_TEXT_X + LETTER_W + LETTER_SP) &&
                       (hcount <  LOSE_TEXT_X + (LETTER_W + LETTER_SP)*2) &&
                       (vcount >= LOSE_TEXT_Y) &&
                       (vcount <  LOSE_TEXT_Y + LETTER_H);

    wire in_S_region = (hcount >= LOSE_TEXT_X + (LETTER_W + LETTER_SP)*2) &&
                       (hcount <  LOSE_TEXT_X + (LETTER_W + LETTER_SP)*3) &&
                       (vcount >= LOSE_TEXT_Y) &&
                       (vcount <  LOSE_TEXT_Y + LETTER_H);

    wire in_E_region = (hcount >= LOSE_TEXT_X + (LETTER_W + LETTER_SP)*3) &&
                       (hcount <  LOSE_TEXT_X + (LETTER_W + LETTER_SP)*4) &&
                       (vcount >= LOSE_TEXT_Y) &&
                       (vcount <  LOSE_TEXT_Y + LETTER_H);

    // relative coords for LOSE letters
    wire [9:0] x_L = hcount - LOSE_TEXT_X;
    wire [9:0] y_L = vcount - LOSE_TEXT_Y;

    wire [9:0] x_O = hcount - (LOSE_TEXT_X + LETTER_W + LETTER_SP);
    wire [9:0] y_O = vcount - LOSE_TEXT_Y;

    wire [9:0] x_S = hcount - (LOSE_TEXT_X + (LETTER_W + LETTER_SP)*2);
    wire [9:0] y_S = vcount - LOSE_TEXT_Y;

    wire [9:0] x_E = hcount - (LOSE_TEXT_X + (LETTER_W + LETTER_SP)*3);
    wire [9:0] y_E = vcount - LOSE_TEXT_Y;

    // "L": left bar + bottom bar
    wire pixel_L =
        (x_L < 3 && y_L < LETTER_H) ||                                    // left bar
        (y_L >= LETTER_H-3 && y_L < LETTER_H && x_L < LETTER_W);         // bottom bar

    // "O": hollow rectangle
    wire pixel_O =
        (y_O < 3 && x_O < LETTER_W) ||                                   // top
        (y_O >= LETTER_H-3 && y_O < LETTER_H && x_O < LETTER_W) ||       // bottom
        (x_O < 3 && y_O < LETTER_H) ||                                   // left
        (x_O >= LETTER_W-3 && x_O < LETTER_W && y_O < LETTER_H);         // right

    // "S": three horizontal bars + two shorts
    wire pixel_S =
        (y_S < 3 && x_S < LETTER_W) ||                                   // top
        (y_S >= LETTER_H/2-1 && y_S <= LETTER_H/2+1 && x_S < LETTER_W) ||// middle
        (y_S >= LETTER_H-3 && y_S < LETTER_H && x_S < LETTER_W) ||       // bottom
        (x_S < 3 && y_S < LETTER_H/2) ||                                 // upper left
        (x_S >= LETTER_W-3 && x_S < LETTER_W &&                          // lower right
         y_S >= LETTER_H/2);

    // "E": left bar + three horizontals
    wire pixel_E =
        (x_E < 3 && y_E < LETTER_H) ||                                   // left bar
        (y_E < 3 && x_E < LETTER_W) ||                                   // top
        (y_E >= LETTER_H/2-1 && y_E <= LETTER_H/2+1 && x_E < LETTER_W) ||// middle
        (y_E >= LETTER_H-3 && y_E < LETTER_H && x_E < LETTER_W);         // bottom

    wire lose_text_pixel = (in_L_region && pixel_L) ||
                           (in_O_region && pixel_O) ||
                           (in_S_region && pixel_S) ||
                           (in_E_region && pixel_E);

    // ----------------------------------------------------------------
    // Final color priority:
    //  1) WIN/LOSE text (if active)
    //  2) enemy bullet
    //  3) player bullet
    //  4) ship (with nose)
    //  5) enemies
    //  6) background (state-dependent color)
    // ----------------------------------------------------------------
    always @* begin
        if (!video_active) begin
            vga_r = 4'h0;
            vga_g = 4'h0;
            vga_b = 4'h0;
        end else if (you_win && win_text_pixel) begin
            // WIN text: bright white
            vga_r = 4'hF;
            vga_g = 4'hF;
            vga_b = 4'hF;
        end else if (you_lose && lose_text_pixel) begin
            // LOSE text: bright white
            vga_r = 4'hF;
            vga_g = 4'hF;
            vga_b = 4'hF;
        end else if (in_enemy_bullet) begin
            // enemy bullet: red
            vga_r = 4'hF;
            vga_g = 4'h0;
            vga_b = 4'h0;
        end else if (in_player_bullet) begin
            // player bullet: yellow
            vga_r = 4'hF;
            vga_g = 4'hF;
            vga_b = 4'h0;
        end else if (in_ship) begin
            // ship + nose: cyan
            vga_r = 4'h0;
            vga_g = 4'hF;
            vga_b = 4'hF;
        end else if (in_enemy) begin
            // enemies: bright green
            vga_r = 4'h0;
            vga_g = 4'hF;
            vga_b = 4'h0;
        end else begin
            // background: show state
            if (you_lose) begin
                // lose: reddish tint
                vga_r = 4'h8;
                vga_g = 4'h0;
                vga_b = 4'h2;
            end else if (you_win) begin
                // win: greenish tint
                vga_r = 4'h0;
                vga_g = 4'h8;
                vga_b = 4'h2;
            end else begin
                // normal play: dark blue
                vga_r = 4'h0;
                vga_g = 4'h0;
                vga_b = 4'h3;
            end
        end
    end
endmodule
