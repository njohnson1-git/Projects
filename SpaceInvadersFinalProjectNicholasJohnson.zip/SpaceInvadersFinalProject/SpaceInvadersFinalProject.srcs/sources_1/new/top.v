// top.v
// Now: VGA + moving ship controlled by two buttons.

module top (
    input  wire CLK100MHZ,     // 100 MHz board clock
    input  wire RESET_BTN,     // reset button (active high)
    input  wire BTN_LEFT,      // move ship left
    input  wire BTN_RIGHT,     // move ship right

    output wire [3:0] VGA_R,
    output wire [3:0] VGA_G,
    output wire [3:0] VGA_B,
    output wire       VGA_HS,
    output wire       VGA_VS
);

    //============================================================
    //  Pixel clock: 100 MHz -> 25 MHz by simple divide-by-4
    //============================================================
    wire clk_pix;

    clk_div_4 clk_div_inst (
        .clk_in  (CLK100MHZ),
        .reset   (RESET_BTN),
        .clk_out (clk_pix)
    );

    //============================================================
    //  VGA timing
    //============================================================
    wire [9:0] hcount;
    wire [9:0] vcount;
    wire       video_active;

    vga vga_timing (
        .clk_pix      (clk_pix),
        .reset        (RESET_BTN),
        .hcount       (hcount),
        .vcount       (vcount),
        .hsync        (VGA_HS),
        .vsync        (VGA_VS),
        .video_active (video_active)
    );

    //============================================================
    //  Game tick (slow enable for movement logic)
    //============================================================
    wire game_tick;

    frame_tick #(
        .TICK_HZ(50)
    ) frame_tick_inst (
        .clk_pix  (clk_pix),
        .reset    (RESET_BTN),
        .tick_out (game_tick)
    );

    // From submodules:
    wire game_over_formation;   // from enemy_mgr
    wire ship_dead;             // from ship_hit
    wire you_win;               // from enemy_mgr

    wire you_lose;
    wire game_over;

    assign you_lose  = game_over_formation | ship_dead;
    assign game_over = you_win | you_lose;

    // When game_over is high, stop all gameplay movement
    wire game_tick_play = game_tick & ~game_over;


    //============================================================
    //  Ship position control
    //============================================================
    wire [9:0] ship_x;
    wire [9:0] ship_y;

    ship_ctrl ship_ctrl_inst (
        .clk_pix   (clk_pix),
        .reset     (RESET_BTN),
        .game_tick (game_tick_play),
        .btn_left  (BTN_LEFT),
        .btn_right (BTN_RIGHT),
        .ship_x    (ship_x),
        .ship_y    (ship_y)
    );
    
    //============================================================
    //  Bullet manager (auto-firing)
    //============================================================
    wire        bullet_active;
    wire [9:0]  bullet_x;
    wire [9:0]  bullet_y;

    bullet_mgr bullet_mgr_inst (
        .clk_pix       (clk_pix),
        .reset         (RESET_BTN),
        .game_tick     (game_tick_play),
        .ship_x        (ship_x),
        .ship_y        (ship_y),
        .bullet_clear  (bullet_hit), 
        .bullet_active (bullet_active),
        .bullet_x      (bullet_x),
        .bullet_y      (bullet_y)
    );


    //============================================================
    //  Enemy manager: formation + collision + game_over + you_win
    //============================================================
    wire [9:0]   enemy_group_x;
    wire [9:0]   enemy_group_y;
    wire [23:0]  enemy_alive;      // 3 rows x 8 cols = 24 enemies
    wire         bullet_hit;

    enemy_mgr #(
        .N_ROWS(3),
        .N_COLS(8)
    ) enemy_mgr_inst (
        .clk_pix             (clk_pix),
        .reset               (RESET_BTN),
        .game_tick           (game_tick_play),
        .bullet_active       (bullet_active),
        .bullet_x            (bullet_x),
        .bullet_y            (bullet_y),
        .group_x             (enemy_group_x),
        .group_y             (enemy_group_y),
        .alive_mask          (enemy_alive),
        .bullet_hit          (bullet_hit),
        .game_over_formation (game_over_formation),
        .you_win             (you_win)
    );


    // full formation width constant (for enemy_bullet_mgr)
    localparam integer ENEMY_W     = 24;
    localparam integer H_SPACING   = 16;
    localparam integer N_COLS      = 8;
    localparam integer FORMATION_W = N_COLS*ENEMY_W + (N_COLS-1)*H_SPACING;

    //============================================================
    //  Enemy bullet manager: one bullet falling downwards
    //============================================================
    wire        ebullet_active;
    wire [9:0]  ebullet_x;
    wire [9:0]  ebullet_y;

    enemy_bullet_mgr #(
        .N_ROWS(3),
        .N_COLS(8)
    ) enemy_bullet_mgr_inst (
        .clk_pix        (clk_pix),
        .reset          (RESET_BTN),
        .game_tick      (game_tick_play),
        .game_over      (game_over),
        .group_x        (enemy_group_x),
        .group_y        (enemy_group_y),
        .alive_mask     (enemy_alive),
        .ebullet_active (ebullet_active),
        .ebullet_x      (ebullet_x),
        .ebullet_y      (ebullet_y)
    );


    //============================================================
    //  Ship hit detector: enemy bullet vs ship -> ship_dead
    //============================================================
    ship_hit ship_hit_inst (
        .clk_pix        (clk_pix),
        .reset          (RESET_BTN),
        .game_tick      (game_tick),       // can use raw tick
        .ebullet_active (ebullet_active),
        .ebullet_x      (ebullet_x),
        .ebullet_y      (ebullet_y),
        .ship_x         (ship_x),
        .ship_y         (ship_y),
        .ship_dead      (ship_dead)
    );


    //============================================================
    //  Renderer: draw background + ship + bullet + enemies
    //============================================================
    game_renderer render_inst (
        .hcount         (hcount),
        .vcount         (vcount),
        .video_active   (video_active),
        .ship_x         (ship_x),
        .ship_y         (ship_y),
        .bullet_active  (bullet_active),
        .bullet_x       (bullet_x),
        .bullet_y       (bullet_y),
        .enemy_group_x  (enemy_group_x),
        .enemy_group_y  (enemy_group_y),
        .enemy_alive    (enemy_alive),
        .ebullet_active (ebullet_active),
        .ebullet_x      (ebullet_x),
        .ebullet_y      (ebullet_y),
        .game_over      (game_over),
        .you_win        (you_win),
        .you_lose       (you_lose),
        .vga_r          (VGA_R),
        .vga_g          (VGA_G),
        .vga_b          (VGA_B)
    );


endmodule


//============================================================
// Simple clock /4 divider: 100 MHz -> 25 MHz
//============================================================
module clk_div_4 (
    input  wire clk_in,
    input  wire reset,
    output wire clk_out
);
    reg [1:0] div_cnt = 2'b00;

    always @(posedge clk_in or posedge reset) begin
        if (reset)
            div_cnt <= 2'b00;
        else
            div_cnt <= div_cnt + 2'b01;
    end

    assign clk_out = div_cnt[1];  // divide by 4

endmodule
